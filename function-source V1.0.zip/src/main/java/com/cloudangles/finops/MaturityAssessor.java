package com.cloudangles.finops;

import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;

import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import java.net.HttpURLConnection;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.io.BufferedWriter;
import java.util.logging.Logger;
import java.util.concurrent.ThreadLocalRandom;
import java.util.*;

import java.util.Properties;    
import javax.mail.*;
import javax.mail.util.*;
import javax.mail.internet.*;
import javax.activation.*;

import org.apache.poi.ss.usermodel.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MaturityAssessor implements HttpFunction {
  private static final Gson gson = new Gson();
  private static final Logger logger = Logger.getLogger(MaturityAssessor.class.getName());
  private int randName = ThreadLocalRandom.current().nextInt();
  
  @Override
  public void service(HttpRequest request, HttpResponse response) throws Exception {

    JsonObject data = new JsonObject();
    JsonObject body = gson.fromJson(request.getReader(), JsonObject.class);
    try{
      logger.info("request Headers are: " + request.getHeaders());
      logger.info("request body is: " + body.toString());
      data = computeMaturity ( body );
    }
    catch (Exception ex){
      data.addProperty("Error: Input Invlid/Uprocessable: ",ex.getLocalizedMessage());
      response.setStatusCode(HttpURLConnection.HTTP_BAD_REQUEST);
    }
    // Set CORS headers
    response.appendHeader("Access-Control-Allow-Origin", "*"); 
    if ("OPTIONS".equals(request.getMethod())) {
      response.appendHeader("Access-Control-Allow-Methods", "POST,GET");
      response.appendHeader("Access-Control-Allow-Headers", "Content-Type,Access-Control-Allow-Origin,access-control-allow-origin,content-type");
      response.appendHeader("Access-Control-Max-Age", "3600");
      response.setStatusCode(HttpURLConnection.HTTP_NO_CONTENT);
      return;
    }

    // Create the Excel doc in the Bucket !!
    createExcelDoc( body, data );

    // Send an Email to the end user
    JsonObject userData = body.getAsJsonObject("userData");

    sendEmail( userData.get("firstName").getAsString(), userData.get("lastName").getAsString(), userData.get("email").getAsString());

    response.setContentType("application/json; charset=UTF-8");
    BufferedWriter writer = response.getWriter();
    writer.write(data.toString()); 
    
    logger.info("Response sent is: " + data.toString());
  } //end method service

  private JsonObject computeMaturity (JsonObject body) throws Exception{

    JsonObject data = new JsonObject();
    if (body == null){
        data.addProperty("Error", "Unreaadable input!");
        return data;

    }

    Set<String> keys = body.keySet();
    double overall_score = 0;

    for (String key: keys) {
      if (! key.equalsIgnoreCase("userData")) {
        double score = getScore( body.getAsJsonArray(key));
        overall_score+= score;
        data.addProperty(key, score);
      }
      else {
        // We need to add user data info in this block ...
        JsonObject userData = body.getAsJsonObject("userData");
        if (userData.has("firstName"))
          data.addProperty("firstname", userData.get("firstName").getAsString());
        else
          data.addProperty("firstname", "noname");
        if (userData.has("lastName"))
          data.addProperty("lastname", userData.get("lastName").getAsString());
        else
          data.addProperty("lastname","noname");
      }
    }

    data.addProperty("overall",overall_score);
    //Overall scoring: <=80 Beginner, >80,<=150 Intermediate,>150 Advanced
    //Beginner    You're in the early stages of developing your cloud cost management capabilities.
    //Intermediate    You have many of the basic best practices in place, and are moving on to optimizing.
    //Advanced    You score highly across most cloud cost management capabilities. Reach out to an analyst for ideas on how to improve.
    if (overall_score > 150){
      data.addProperty("rating","Advanced");
      data.addProperty("rating_text","You score highly across most cloud cost management capabilities. Reach out to an analyst for ideas on how to improve.");
    }
    else{
      if (overall_score > 80){
        data.addProperty("rating","Intermediate");
        data.addProperty("rating_text","You have many of the basic best practices in place, and are moving on to optimizing.");
      }
      else{
        data.addProperty("rating","Beginner");
        data.addProperty("rating_text","You're in the early stages of developing your cloud cost management capabilities.");
      }
    }

    return data.deepCopy();

  }

  private double getScore( JsonArray objArray ) throws Exception {
    double score = 0;
    
    for( JsonElement elem : objArray ) {
      // individual Object in array.
      JsonObject obj = elem.getAsJsonObject();

      Set<String> allKeys = obj.keySet();
      for ( String key: allKeys ) {
        if (obj.getAsJsonObject(key).has("answer") ) {
          score += getMappedScore(obj.getAsJsonObject(key).get("answer").getAsInt());
        }
        logger.info("Score on " + key + " is " + score);
      }
    }
    return score;
  }

  private double getMappedScore( int value ) {
    double mScore = 0;
    switch( value ) {
      case 6:
      mScore = 3;
      break;
      case 5:
      mScore = 2;
      break;
      case 4:
      mScore = 1;
      break;
      case 3:
      mScore = 0.5;
      break;
      case 2:
      mScore = 0.25;
      break;
      case 1:
      mScore = 0;
      break;
      default:
      mScore = -99;
      break;

    }
    return mScore;
  }

  private String getScoreString( int value ) {
    String mScore;
    switch( value ) {
      case 6:
        mScore = "Strongly Agree";
        break;
      case 5:
        mScore = "Somewhat Agree";
        break;
      case 4:
        mScore = "Agree";
        break;
      case 3:
        mScore = "Disagree";
        break;
      case 2:
        mScore = "Somewhat Disagree";
        break;
      case 1:
        mScore = "Strongly Disagree";
        break;
      default:
        mScore = "I do not know";
      break;

    }
    return mScore;

  }

  private void createExcelDoc( JsonObject body, JsonObject data ) throws Exception {

        // The ID of your GCP project
    String projectId = "development-328905";

    // The ID of your GCS bucket
    String bucketName = "finsecops";

    // The ID of your GCS object
    String objectName = "FinOpsMatAssTemplateV2.0.xlsx";
    logger.info("Using template - " + objectName);

    Storage storage = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
    byte[] in_content = storage.readAllBytes(bucketName, objectName);

        //Blank workbook
    XSSFWorkbook workbook = new XSSFWorkbook( new ByteArrayInputStream(in_content));

    CellStyle borderStyle = workbook.createCellStyle();
    borderStyle.setBorderBottom(CellStyle.BORDER_THIN);
    borderStyle.setBorderLeft(CellStyle.BORDER_THIN);
    borderStyle.setBorderRight(CellStyle.BORDER_THIN);
    borderStyle.setBorderTop(CellStyle.BORDER_THIN);
    borderStyle.setAlignment(CellStyle.ALIGN_LEFT);

    CellStyle borderStyleWithCenter = workbook.createCellStyle();
    borderStyleWithCenter.setBorderBottom(CellStyle.BORDER_THIN);
    borderStyleWithCenter.setBorderLeft(CellStyle.BORDER_THIN);
    borderStyleWithCenter.setBorderRight(CellStyle.BORDER_THIN);
    borderStyleWithCenter.setBorderTop(CellStyle.BORDER_THIN);
    borderStyleWithCenter.setAlignment(CellStyle.ALIGN_CENTER);

    //Create a blank sheet
    XSSFSheet sheet = workbook.getSheetAt(0);

    JsonObject userData = body.getAsJsonObject("userData");
    System.out.println( userData.toString());
    Row rowname = sheet.getRow(0);
    Cell cellname = rowname.createCell(1);

    String firstName = userData.get("firstName").getAsString();
    String lastName = userData.get("lastName").getAsString();
    
    cellname.setCellValue( firstName + " " + lastName );

    String document_name = userData.get("firstName").getAsString() + "_" + userData.get("lastName").getAsString() + ".xlsx" ;
    logger.info("Result stored in: //" + projectId + "/" + bucketName + "/" + document_name);

    Row rowcmp = sheet.getRow(1);
    Cell cellcmp = rowcmp.createCell(1);
    cellcmp.setCellValue(userData.get("company").getAsString());

    Row rowdes = sheet.getRow(2);
    Cell celldes = rowdes.createCell(1);
    celldes.setCellValue(userData.get("des").getAsString());

    Row rowph = sheet.getRow(3);
    Cell cellph = rowph.createCell(1);
    cellph.setCellValue(userData.get("phone").getAsString());

    Row rowemail = sheet.getRow(4);
    Cell cellemail = rowemail.createCell(1);
    cellemail.setCellValue(userData.get("email").getAsString());

    Row rowfb = sheet.getRow(5);
    Cell cellfb = rowfb.createCell(1);
    cellfb.setCellValue(userData.get("comment").getAsString());
    
    // Add the maturity data now in sheet 1 starting at row 7
    int rowNm = 6;
    Row row = sheet.getRow(rowNm ++);
    Cell cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("overall").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("Foundation").getAsDouble());
    
    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("Roles").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("culture").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("architech").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("visi").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("budget").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("governance").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("value").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("rightSize").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("purchase").getAsDouble());

    row = sheet.getRow(rowNm ++);
    cell = row.createCell(1);
    cell.setCellStyle( borderStyleWithCenter);
    cell.setCellValue(data.get("process").getAsDouble());

    //Lock the Worksheet against changes: using hard-coded, standard password for all
    sheet.protectSheet("is2JPD7}NRPVkcEF4gyu7R&");

    // Now we need to get the second sheet to populate the values
    // of all the questionaire
    sheet = workbook.getSheetAt(1);
    
    // Now for Foundation answers
    int rowNumber = 2;
    JsonArray dataArray = body.getAsJsonArray("Foundation"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

  // populate data for roles questions ..
    rowNumber = 5;
    dataArray = body.getAsJsonArray("Roles"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

  // populate data for culture questions ..
    rowNumber = 11;
    dataArray = body.getAsJsonArray("culture"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for architech questions ..
    rowNumber = 18;
    dataArray = body.getAsJsonArray("architech"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for visibility questions ..
    rowNumber = 24;
    dataArray = body.getAsJsonArray("visi"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for budget questions ..
    rowNumber = 37;
    dataArray = body.getAsJsonArray("budget"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for governance questions ..
    rowNumber = 45;
    dataArray = body.getAsJsonArray("governance"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for value questions ..
    rowNumber = 52;
    dataArray = body.getAsJsonArray("value"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for rightSize questions ..
    rowNumber = 59;
    dataArray = body.getAsJsonArray("rightSize"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for purchase questions ..
    rowNumber = 67;
    dataArray = body.getAsJsonArray("purchase"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    // populate data for process questions ..
    rowNumber = 74;
    dataArray = body.getAsJsonArray("process"); 
    addDataToExcell( dataArray, sheet, rowNumber, borderStyle);

    //Lock the Worksheet against changes: using hard-coded, standard password for all
    sheet.protectSheet("B(7n^rmJQod4'=Z0%{wWg,R");

    ByteArrayOutputStream out = new ByteArrayOutputStream();
    workbook.write(out);

    BlobId blobId = BlobId.of(bucketName, document_name);
    BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
    byte[] content = out.toByteArray();
    storage.createFrom(blobInfo, new ByteArrayInputStream(content));

  }

  private void addDataToExcell( JsonArray array, XSSFSheet sheet, int rowNumber, CellStyle borderStyle ) throws Exception {

    Cell cell;
    for (JsonElement elem: array) {
      JsonObject obj = elem.getAsJsonObject();
      Set<String> objKeys = obj.keySet();
      Object[] keys = objKeys.toArray();

      cell = sheet.getRow( rowNumber  ).createCell(2);
      cell.setCellStyle(borderStyle);
      cell.setCellValue(  getScoreString( obj.getAsJsonObject(keys[0].toString()).get("answer").getAsInt() ) );

      cell = sheet.getRow( rowNumber++).createCell(3);
      cell.setCellStyle(borderStyle);
      cell.setCellValue(obj.getAsJsonObject(keys[0].toString()).get("comment").getAsString() );
    }
  }

  private void sendEmail( String firstName, String lastName, String toEmail ) throws Exception {

    Properties props = new Properties();    
    props.put("mail.smtp.host", "smtp.office365.com"); 
    props.setProperty("mail.smtp.starttls.enable", "true");  
    props.put("mail.smtp.socketFactory.port", "587");    
    props.put("mail.smtp.socketFactory.class",    
            "javax.net.ssl.SSLSocketFactory");    
    props.put("mail.smtp.auth", "true");    
    props.put("mail.smtp.port", "587");

    logger.info("Begining to send email to " + firstName + " at " + toEmail);
    //get Session   
    Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {    
        protected PasswordAuthentication getPasswordAuthentication() {    
            return new PasswordAuthentication("finopssystems@cloudangles.com", "Cloud_Angles#123");
        }    
    });    
    //compose message    
    try {    
        MimeMessage message = new MimeMessage(session);
        
        message.setFrom(new InternetAddress("finopsmaturityassessor@cloudangles.com","CloudAngles FinSecOps Assessment System - NORPELY"));

        message.addRecipient(Message.RecipientType.TO,new InternetAddress(toEmail,lastName + ',' + firstName));
        message.addRecipient(Message.RecipientType.CC,new InternetAddress("finopsmatassessmentrequest@cloudangles.com","CloudAngles FinSecOps Team"));


        String msgStr = "Dear " + firstName + ",\n\n" +
          "Thanks for your interest in our FinOps capabilities and taking the Maturity Questionnaire. We've attached a copy of the report assessing the level of your maturity based on the answers you provided.\n\n" +
          "Looking forward to seeing your further interest and working to enhancing your organization cost management: reach out to us at finopsmatassessmentrequests@cloudangles.com.\n\n" +
          "Regards\n\n" +
          "CloudAngles FinSecOps Team";  
        message.setSubject( "Thanks for taking the CloudAngles FinSecOps Maturity Assessment", "UTF-8");

        BodyPart messageBodyPart1 = new MimeBodyPart();  
        messageBodyPart1.setText( msgStr );  
        
        //4) create new MimeBodyPart object and set DataHandler object to this object      
        MimeBodyPart messageBodyPart2 = new MimeBodyPart();

        // The ID of your GCP project
        String projectId = "development-328905";

        // The ID of your GCS bucket
        String bucketName = "finsecops";

        // The ID of your GCS object
        String objectName = firstName + "_" + lastName +".xlsx";

        Storage storage = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
        byte[] in_content = storage.readAllBytes(bucketName, objectName);

    
        //String filename = "SendAttachment.java";//change accordingly  
        DataSource source = new ByteArrayDataSource(in_content, "application/vnd.ms-excel"); //new FileDataSource(filename);  
        messageBodyPart2.setDataHandler(new DataHandler(source));  
        messageBodyPart2.setFileName(objectName);  
        
        //5) create Multipart object and add MimeBodyPart objects to this object      
        Multipart multipart = new MimeMultipart();  
        multipart.addBodyPart(messageBodyPart1);  
        multipart.addBodyPart(messageBodyPart2);  
    
        //6) set the multiplart object to the message object  
        message.setContent(multipart );  
        //send message  
        Transport.send(message); 
      } catch (MessagingException e) {
          throw new RuntimeException(e);
      }   

  }

} //end class Example